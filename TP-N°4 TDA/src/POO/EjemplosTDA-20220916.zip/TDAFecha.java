/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tdafecha;
import java.util.Scanner;

/**
 *
 * @author ccarrasco
 */
public class TDAFecha {

    /**
     * @param args the command line arguments
     */
    
	public static void main (String [] args) 
	{
	
		int unDia;
		int unMes;
		int unAnio;
		
		Fecha hoy;
		Fecha otraFecha;
		Fecha fechaInicio;
		Fecha fechaInicio1900;
	
		
		//Creo una fecha a partir de un dia
                
		hoy= new Fecha(15, 9, 2022);
                
                if (!hoy.esFechaCorrecta())
                    System.out.println ("La fecha ingresada es:"+ hoy.fechaLarga());
                else
                    System.out.println ("Los datos ingresados son incorrectos");
                
                //Creo una fecha a partir de los datos que ingresa un usuario
                Scanner sc = new Scanner(System.in);
		
                do
                {
                    System.out.println ("Ingrese el dia del mes");
                    unDia = sc.nextInt();
                    System.out.println ("Ingrese el mes");
                    unMes = sc.nextInt();
                    System.out.println ("Ingrese el año");
                    unAnio = sc.nextInt();
                    otraFecha= new Fecha(unDia, unMes, unAnio);
                } while (!otraFecha.esFechaCorrecta());
                               
		
                
		//Creo una fecha usando el constructor sin parametros
		fechaInicio= new Fecha();
		
		//Creao una fecha con el primer dia del a�o 1900
		fechaInicio1900=new Fecha(1,1,1900);
		
		System.out.println ("La fecha de hoy es: " + hoy.toString());
		System.out.println ("La fecha ingresada por el usuario es: " + otraFecha.toString());
   		System.out.println ("La fecha de inicio es: " + fechaInicio.toString());
		
                System.out.println ("La fecha de hoy en formato largo es: " + hoy.fechaLarga());
		System.out.println ("La fecha ingresada en formato largo es: " + otraFecha.fechaLarga());
		System.out.println ("La fecha de inicio en formato largo es: " + fechaInicio.fechaLarga());
                
                
		MostrarBisiesto(hoy);
		MostrarBisiesto(otraFecha);
		MostrarBisiesto(fechaInicio);
		
                
                /*ATENCION! voy a usar el método estático acá*/
                System.out.println ("Ingrese un año");
                unAnio = sc.nextInt();
                
                boolean bisiesto=false;
		
		bisiesto=Fecha.esBisiesto(unAnio); // --> uso el método esBisiesto directamente con la clase! No hay objeto.
		
		if (bisiesto)
			System.out.println ("El año " + unAnio + " es BISIESTO");
		else
			System.out.println ("El año" + unAnio + " NO es Bisiesto");
                    
		
		//Veamos si son iguales!
		if (fechaInicio==fechaInicio1900)
			System.out.println ("fechaInicio y fechaInicio1900 son el mismo objeto");
		else
				System.out.println ("fechaInicio y fechaInicio1900  NO son el mismo objeto");
				
		if (fechaInicio.equals(fechaInicio1900))
				System.out.println ("fechaInicio y fechaInicio1900 son iguales");
		else
				System.out.println ("fechaInicio y fechaInicio1900 NO son iguales");
		
	}
	
	
	public static void MostrarBisiesto(Fecha unaFecha)
	{
		boolean bisiesto=false;
		
		bisiesto=unaFecha.esBisiesto();
		
		if (bisiesto)
			System.out.println ("El anio de la fecha " + unaFecha.toString() + " es BISIESTO");
		else
			System.out.println ("El anioo de la fecha " + unaFecha.toString() +  " NO es Bisiesto");	
	}
        
        public static void MostrarBisiesto(int unAnio)
	{
		boolean bisiesto=false;
		
		bisiesto=Fecha.esBisiesto(unAnio);
		
		if (bisiesto)
			System.out.println ("El año " + unAnio + " es BISIESTO");
		else
			System.out.println ("El año" + unAnio + " NO es Bisiesto");	
	}
    
}
