package Ejemplo;

import utiles.TecladoIn;

public class TestEspecie {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Especie e1, e2;
        System.out.println("Ingrese la primera especie");
        e1=leerEspecie();
        System.out.println("Ingrese la segunda especie");
        e2=leerEspecie();
        System.out.println("Las especies cargadas son:");
        mostrarEspecie(e1);
        mostrarEspecie(e2);
        if (!e1.equals(e2)){
            System.out.println("La primera especie va a superar "+
                    "a la segunda especie en "+
                    calculaCrecimiento(e1,e2)+" anios");
        }
        else {
            System.out.println("Especies iguales");
        }
        
    }

    private static Especie leerEspecie(){
    	Especie e = new Especie();
    	
        System.out.print("Nombre de la especie: ");
        String nom = TecladoIn.readLine();
        System.out.print("Poblacion actual: ");
        int pob = TecladoIn.readLineInt();
        System.out.print("Tasa anual de crecimiento: ");
        double tasa = TecladoIn.readLineDouble();
        e.setNombre(nom);
        e.setPoblacion(pob);
        e.setTasaDeCrecimiento(tasa);
        return e;
    }
    private static void mostrarEspecie(Especie e){
        System.out.println(e.getNombre()+" Poblacion: "+
                e.getPoblacion()+" Tasa anual: "+e.getTasaDeCrecimiento());
    }

    private static int calculaCrecimiento(Especie x, Especie y){
    	// calcula la diferencia en anios entre las tasas de crecimiento de ambas especies
        int anios = 0;
        int p1 = x.getPoblacion();
        int p2 = y.getPoblacion();
        while (p1<=p2 && anios < 100){
            p1 = p1 + (int)(p1*x.getTasaDeCrecimiento());
            p2 = p2 + (int)(p2*y.getTasaDeCrecimiento());
            anios++;
        }
        return anios; 
    }
}
