/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tdafecha;

/**
 *
 * @author ccarrasco
 */
public class Fecha
{

	//Atributos
	
	private int dia;
	private int mes;
	private int anio;
        private boolean fechaCorrecta;
	
	//Constructores
	public Fecha()	//constructor sin par�metros
	{
		dia=1;
		mes=1;
		anio=1900;
                fechaCorrecta=true;
	}
	
	public Fecha(int elDia, int elMes, int elAnio)
	{
            fechaCorrecta=true;

	    if (elAnio>0 || elAnio<10000)
                anio=elAnio;
            else
		anio=0;
            
	    if (elMes >0 && elMes <13)
                    mes=elMes;
            else
                    mes=0;

            if (elDia>31 || elDia <1)
			dia=0;
		else
		{
				if (elDia<29)
					dia=elDia;
				else
				{
					switch (dia)
					{
					
						case 29:
							if (mes==2)
							{
								if (esBisiesto())
									dia=elDia;
								else
									dia=0;
							}			
							else
								dia=elDia;
							break;	
							
						case 30:
							if (mes==2)
								dia=0;
							else 
								dia=elDia;
							break;
							
						case 31:
                                                       if (mes==2 || mes ==11 || mes==4 || mes==6 || mes==9 )
								dia=0;
							else 
								dia=elDia;
							break;
					}
				}
		}

            /* Al finalizar todo, Verifico si la fecha es correcta */
            fechaCorrecta=(anio==0 || mes==0 || anio==0?false:true);
            
            //o bien 
            if (anio==0 || mes==0 || anio==0)
                fechaCorrecta=false;

           
	}
	
	//Métodos - Comportamiento
        
	//************************************************************
	//OBSERVADORES
        //************************************************************
	public int getDia()
	{
		return dia;
	}
	
	public int getMes()
	{
		return mes;
	}
	
	public int getAnio()
	{
		return anio;
	}
        
        public String toString()
	{
		return dia + "/" + mes + "/" + anio ;
	}
        
	
        //************************************************************
	//MODIFICADORES
        //************************************************************
        
	
	//************************************************************
	//PROPIOS DEL TIPO
        //************************************************************
	public boolean esBisiesto()
	{
		boolean bisiesto=false;
		
		if ((anio % 4 == 0) && ((anio % 100 != 0) || (anio % 400 == 0)))
			bisiesto=true;
		
		return bisiesto;
		
	}
        
	//Este método, a diferencia del anterior, es ESTATICO, lo 
        //puedo utilizar sin necesidad de crear un objeto, es propio de la clase
        //Ver ejemplo en clase Test
	public static boolean esBisiesto(int elAnio)
	{
		boolean bisiesto=false;
		
		if ((elAnio % 4 == 0) && ((elAnio % 100 != 0) || (elAnio % 400 == 0)))
			bisiesto=true;
		
		return bisiesto;
		
	}
	
	
	public String mesLetras()
	{
		String mesEnLetras="";
		
		switch (mes)
		{
			case 1:
				mesEnLetras="Enero";
				break;
			case 2:
				mesEnLetras="Febrero";
				break;
			case 3:
				mesEnLetras="Marzo";
				break;
			case 4:
				mesEnLetras="Abril";
				break;
			case 5:
				mesEnLetras="Mayo";
				break;
			case 6:
				mesEnLetras="Junio";
				break;
			case 7:
				mesEnLetras="Julio";
				break;
			case 8:
				mesEnLetras="Agosto";
				break;
			case 9:
				mesEnLetras="Setiembre";
				break;
			case 10:
				mesEnLetras="Octubre";
				break;
			case 11:
				mesEnLetras="Noviembre";
				break;
			case 12:
				mesEnLetras="Diciembre";
				break;
	
	
		}
	
		return  mesEnLetras;
	}
	
	
	public String fechaLarga()
	{
		return  dia + " de " + mesLetras() + " de " + anio ;
	}
	
	public String fechaCorta()
	{
		return toString();
	}
        
        /*Este método lo voy a usar para saber si la fecha creada es correcta 
        o no desde el programa de TEST*/
        public boolean esFechaCorrecta()
        {
		return fechaCorrecta==true;
	}
	
	public boolean equals(Fecha otraFecha)
	{
		return dia==otraFecha.getDia() && mes==otraFecha.getMes() && anio==otraFecha.getAnio();
	
	}
}